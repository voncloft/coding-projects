%TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*%
%TF.CreationDate,2026-09-21T04:07:53-04:00*%
%TF.ProjectId,battery-light,62617474-6572-4792-9d6c-696768742e6b,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-09-21 04:07:53*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.218750X0.256250X-0.218750X0.256250X0.218750X-0.256250X0.218750X-0.256250X-0.218750X0*%
%ADD11C,2.200000*%
%ADD12RoundRect,0.150000X-0.150000X-0.700000X0.150000X-0.700000X0.150000X0.700000X-0.150000X0.700000X0*%
%ADD13RoundRect,0.250000X-0.250000X-1.150000X0.250000X-1.150000X0.250000X1.150000X-0.250000X1.150000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,D2*%
X7899999Y-3787500D03*
X7899999Y-2212500D03*
%TD*%
D11*
%TO.C,H1*%
X1500000Y-2000000D03*
%TD*%
D10*
%TO.C,D1*%
X6100000Y-3787500D03*
X6100000Y-2212500D03*
%TD*%
D11*
%TO.C,H2*%
X12500000Y-2000000D03*
%TD*%
D12*
%TO.C,J1*%
X5750000Y-10950000D03*
X7000000Y-10950000D03*
X8250000Y-10950000D03*
D13*
X3900000Y-7600000D03*
X10100000Y-7600000D03*
%TD*%
M02*
